import json
import uuid
from botocore.exceptions import ClientError
from aws_clients import get_iam_client, get_sts_client
from config import AWS_REGION_NAME
from common_utils import json_serializer

def create_bedrock_execution_role(bucket_name, course_id):
    iam_client = get_iam_client()

    # Use the course_id to generate unique suffix
    suffix = str(course_id).replace("-", "")[:8]
    bedrock_execution_role_name = f'AmazonBedrockExecutionRoleForKnowledgeBase_{suffix}'
    fm_policy_name = f'AmazonBedrockFoundationModelPolicyForKnowledgeBase_{suffix}'
    s3_policy_name = f'AmazonBedrockS3PolicyForKnowledgeBase_{suffix}'
    bedrock_kb_policy_name = f'AmazonBedrockKnowledgeBasePolicy_{suffix}'
    admin_policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"

    # Define policy documents
    foundation_model_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["bedrock:InvokeModel"],
                "Resource": [
                    f"arn:aws:bedrock:{AWS_REGION_NAME}::foundation-model/amazon.titan-embed-text-v1"
                ]
            }
        ]
    }

    s3_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": [
                    f"arn:aws:s3:::{bucket_name}",
                    f"arn:aws:s3:::{bucket_name}/*"
                ]
            }
        ]
    }

    assume_role_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "bedrock.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }
        ]
    }
    
    bedrock_kb_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "bedrock:CreateKnowledgeBase",
                    "bedrock:CreateDataSource",
                    "bedrock:GetKnowledgeBase",
                    "bedrock:ListKnowledgeBases",
                    "bedrock:GetDataSource",
                    "bedrock:ListDataSources",
                    "bedrock:DeleteKnowledgeBase",
                    "bedrock:UpdateKnowledgeBase"
                ],
                "Resource": "*"
            }
        ]
    }

    try:
        # Check if the role already exists
        existing_role = iam_client.get_role(RoleName=bedrock_execution_role_name)
        print(f"Role {bedrock_execution_role_name} already exists.")
        return existing_role

    except iam_client.exceptions.NoSuchEntityException:
        print(f"Role {bedrock_execution_role_name} does not exist. Proceeding to create...")

    try:
        # Create policies if they do not exist
        fm_policy = create_or_get_policy(iam_client, fm_policy_name, foundation_model_policy_document)
        s3_policy = create_or_get_policy(iam_client, s3_policy_name, s3_policy_document)
        bedrock_kb_policy = create_or_get_policy(iam_client, bedrock_kb_policy_name, bedrock_kb_policy_document)


        # Create the Bedrock Execution Role
        bedrock_execution_role = iam_client.create_role(
            RoleName=bedrock_execution_role_name,
            AssumeRolePolicyDocument=json.dumps(assume_role_policy_document, default=json_serializer),
            Description='Amazon Bedrock Knowledge Base Execution Role for accessing OSS and S3',
            MaxSessionDuration=3600
        )

        # Attach policies to the role
        iam_client.attach_role_policy(
            RoleName=bedrock_execution_role_name,
            PolicyArn=fm_policy["Policy"]["Arn"]
        )
        iam_client.attach_role_policy(
            RoleName=bedrock_execution_role_name,
            PolicyArn=s3_policy["Policy"]["Arn"]
        )
        iam_client.attach_role_policy(
            RoleName=bedrock_execution_role_name,
            PolicyArn=bedrock_kb_policy["Policy"]["Arn"]
        )
        iam_client.attach_role_policy(
            RoleName=bedrock_execution_role_name,
            PolicyArn=admin_policy_arn
        )


        return bedrock_execution_role

    except ClientError as e:
        print(f"Error creating role or policies: {e}")
        raise e


def create_or_get_policy(iam_client, policy_name, policy_document):
    try:
        # Correct the ARN format by including the AWS account ID
        account_id = get_sts_client().get_caller_identity().get('Account')
        policy_arn = f"arn:aws:iam::{account_id}:policy/{policy_name}"

        # Check if policy already exists
        existing_policy = iam_client.get_policy(PolicyArn=policy_arn)
        print(f"Policy {policy_name} already exists.")
        return existing_policy

    except iam_client.exceptions.NoSuchEntityException:
        print(f"Policy {policy_name} does not exist. Creating...")
        # Create policy if it doesn't exist
        return iam_client.create_policy(
            PolicyName=policy_name,
            PolicyDocument=json.dumps(policy_document, default=json_serializer),
            Description=f'Policy for {policy_name}'
        )

def create_oss_policy_attach_bedrock_execution_role(course_id, collection_id, bedrock_kb_execution_role):
    iam_client = get_iam_client()
    account_number = get_sts_client().get_caller_identity().get('Account')

    # Define OSS policy document
    oss_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "aoss:APIAccessAll"
                ],
                "Resource": [
                    f"arn:aws:aoss:{AWS_REGION_NAME}:{account_number}:{collection_id}"
                ]
            }
        ]
    }

    # Generate a unique suffix using UUID for policy name
    truncated_course_id = str(course_id).replace("-", "")[:8]
    oss_policy_name = f"AmazonBedrockOSSPolicyForKnowledgeBase_{truncated_course_id}"

    try:
        # Create or get OSS policy
        oss_policy = create_or_get_policy(iam_client, oss_policy_name, oss_policy_document)

        # Attach OSS policy to the Bedrock execution role
        oss_policy_arn = oss_policy["Policy"]["Arn"]
        iam_client.attach_role_policy(
            RoleName=bedrock_kb_execution_role["Role"]["RoleName"],
            PolicyArn=oss_policy_arn
        )

        return None

    except Exception as e:
        print(f"Failed to create or attach OSS policy: {e}")
