import boto3
from botocore.client import Config
from opensearchpy import AWSV4SignerAuth
from config import AWS_REGION_NAME

def get_credentials():
    # Create a session to get credentials
    session = boto3.Session()
    credentials = session.get_credentials()

    # Setup AWS4Auth with the correct parameters
    awsauth = AWSV4SignerAuth(credentials, AWS_REGION_NAME, 'aoss')

    sts_client = session.client('sts')
    identity_info = sts_client.get_caller_identity()
    account_number = identity_info.get('Account')
    identity = identity_info['Arn']

    return awsauth, account_number, identity

def get_transcribe_client():
    return boto3.client('transcribe', region_name=AWS_REGION_NAME)

def get_dynamodb_object():
    return boto3.resource('dynamodb', region_name=AWS_REGION_NAME)

def get_transcribe_client():
    return boto3.client('transcribe', region_name=AWS_REGION_NAME)

def get_s3_client():
    return boto3.client('s3', region_name=AWS_REGION_NAME)

def get_cognito_client():
    return boto3.client('cognito-idp', region_name=AWS_REGION_NAME)

def get_ses_client():
    return boto3.client('ses', region_name=AWS_REGION_NAME)

def get_bedrock_client():
    return boto3.client('bedrock', region_name=AWS_REGION_NAME)

def get_opensearch_client():
    return boto3.client('opensearchserverless', region_name=AWS_REGION_NAME)

def get_iam_client():
    return boto3.client('iam', region_name=AWS_REGION_NAME)

def get_sts_client():
    return boto3.client('sts', region_name=AWS_REGION_NAME)

def get_bedrock_agent_client():
    return boto3.client('bedrock-agent', region_name=AWS_REGION_NAME)

def get_bedrock_agent_runtime_client():
    bedrock_config = Config(connect_timeout=300, read_timeout=300, retries={'max_attempts': 2})
    return boto3.client('bedrock-agent-runtime', region_name=AWS_REGION_NAME, config=bedrock_config)
