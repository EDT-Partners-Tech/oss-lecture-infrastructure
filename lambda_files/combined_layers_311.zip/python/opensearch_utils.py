import json
from aws_clients import get_credentials, get_opensearch_client, get_iam_client, get_sts_client
from config import AWS_LAMBDA_EXECUTION_ROLE, AWS_REGION_NAME
from common_utils import json_serializer

def create_policies_in_oss(vector_store_name, bedrock_kb_execution_role_arn, course_id):
    opensearch_client = get_opensearch_client()
    awsauth, account_number, identity = get_credentials()
    truncated_course_id = str(course_id).replace("-", "")[:8]
    
    encryption_policy_name = f"bedrock-rag-sp-{truncated_course_id}"
    network_policy_name = f"bedrock-rag-np-{truncated_course_id}"
    access_policy_name = f"bedrock-rag-ap-{truncated_course_id}"
    
    lambda_function_arn = f"arn:aws:iam::{account_number}:role/bedrock-creation-role"
    lambda_execution_role_arn = f"arn:aws:iam::{account_number}:role/{AWS_LAMBDA_EXECUTION_ROLE}"

    def create_security_policy(name, policy, policy_type):
        try:
            print(f"Attempting to create {policy_type} policy with name: {name}")
            return opensearch_client.create_security_policy(
                name=name,
                policy=json.dumps(policy, default=json_serializer),
                type=policy_type
            )
        except opensearch_client.exceptions.ConflictException:
            print(f"Policy {name} of type {policy_type} already exists. Skipping creation.")
            return None
        except Exception as e:
            print(f"Unexpected error while creating {policy_type} policy {name}: {e}")
            raise e

    def create_access_policy(name, policy):
        try:
            print(f"Attempting to create access policy with name: {name}")
            return opensearch_client.create_access_policy(
                name=name,
                policy=json.dumps(policy, default=json_serializer),
                type="data"
            )
        except opensearch_client.exceptions.ConflictException:
            print(f"Access policy {name} already exists. Skipping creation.")
            return None
        except Exception as e:
            print(f"Unexpected error while creating access policy {name}: {e}")
            raise e

    # Define policies
    encryption_policy = create_security_policy(
        encryption_policy_name,
        {
            'Rules': [{'Resource': [f'collection/{vector_store_name}'], 'ResourceType': 'collection'}],
            'AWSOwnedKey': True
        },
        'encryption'
    )

    network_policy = create_security_policy(
        network_policy_name,
        [
            {'Rules': [{'Resource': [f'collection/{vector_store_name}'], 'ResourceType': 'collection'}],
             'AllowFromPublic': True}
        ],
        'network'
    )

    access_policy = create_access_policy(
        access_policy_name,
        [
            {
                'Rules': [
                    {
                        'Resource': [f'collection/{vector_store_name}'],
                        'Permission': [
                            'aoss:CreateCollectionItems',
                            'aoss:DeleteCollectionItems',
                            'aoss:UpdateCollectionItems',
                            'aoss:DescribeCollectionItems'
                        ],
                        'ResourceType': 'collection'
                    },
                    {
                        'Resource': ['index/' + vector_store_name + '/*'],
                        'Permission': [
                            'aoss:CreateIndex',
                            'aoss:DeleteIndex',
                            'aoss:UpdateIndex',
                            'aoss:DescribeIndex',
                            'aoss:ReadDocument',
                            'aoss:WriteDocument'],
                        'ResourceType': 'index'
                    }
                ],
                'Principal': [identity, bedrock_kb_execution_role_arn, lambda_function_arn, lambda_execution_role_arn],
                'Description': 'Data access policy'
            }
        ]
    )

    return encryption_policy, network_policy, access_policy

def attach_oss_policy(collection_id, bedrock_kb_execution_role):
    iam_client = get_iam_client()
    account_number = get_sts_client().get_caller_identity().get('Account')

    oss_policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["aoss:APIAccessAll"],
                "Resource": [
                    f"arn:aws:aoss:{AWS_REGION_NAME}:{account_number}:collection/{collection_id}"
                ]
            }
        ]
    }

    policy_name = f"AmazonBedrockOSSPolicy_{collection_id}"
    try:
        print(f"Creating IAM policy: {policy_name}")
        oss_policy = iam_client.create_policy(
            PolicyName=policy_name,
            PolicyDocument=json.dumps(oss_policy_document, default=json_serializer),
            Description='Policy for OpenSearch Serverless access'
        )
    except iam_client.exceptions.EntityAlreadyExistsException:
        print(f"IAM policy {policy_name} already exists. Skipping creation.")
        return None
    except Exception as e:
        print(f"Error creating IAM policy {policy_name}: {e}")
        raise e

    iam_client.attach_role_policy(
        RoleName=bedrock_kb_execution_role["Role"]["RoleName"],
        PolicyArn=oss_policy["Policy"]["Arn"]
    )
