import os

# S3 buckets
AUDIO_BUCKET_NAME = os.getenv('AWS_S3_AUDIO_BUCKET_NAME','lecture-audiofiles')
CONTENT_BUCKET_NAME = os.getenv('AWS_S3_CONTENT_BUCKET_NAME', 'lecture-content')

# AWS region
AWS_REGION_NAME = os.getenv('AWS_REGION_NAME', 'eu-central-1')

# DynamoDB table
TRANSCRIPTION_JOBS_DYNAMODB_TABLE_NAME = os.getenv('AWS_TRANSCRIPTION_JOBS_DYNAMODB_TABLE_NAME', 'async-transcription-jobs')

# Lambda execution role
AWS_LAMBDA_EXECUTION_ROLE = os.getenv('AWS_LAMBDA_EXECUTION_ROLE', 'lecture-lambda-execution-role')